#4
def bai4():
    n=int(input())
    if n%3==0 and n!=3:
        return ' co 1 cach'
    else:
        return 'het cach'
            
print(bai4())