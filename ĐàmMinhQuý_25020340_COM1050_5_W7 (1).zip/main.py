#bai1
def kiem_tra_tamgiac():
    a=int(input())
    b=int(input())
    c=int(input())
    if a+b>c and a+c>b and b+c>a:
        if a==b==c:
            return "Tam giac deu"
        elif a==b or b==c or a==c:
            return "Tam giac can"
        elif a*a+b*b==c*c or a*a+c*c==b*b or b*b+c*c==a*a:
            return "Tam giac vuong"
        else:
            return 'Tam giac thuong'
    else:
        return 'Khong phai tam giac'    

  





    