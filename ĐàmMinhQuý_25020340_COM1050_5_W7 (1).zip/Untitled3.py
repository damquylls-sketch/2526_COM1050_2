
#3
def bai3():
    n=int(input())
    return n//2
print(bai3())