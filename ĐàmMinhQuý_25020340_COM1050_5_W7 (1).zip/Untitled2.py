
#bai2
def phan_tich_n():
    n=int(input())
    a=[]
    for i in range(2,n+1):
        if n%i==0 :
            a.append(i)
            n/=i
            if n ==1:
                break 
    for i in a:
        if n%i==0:
            a.append(i)
            n/=i
            if n ==1:
                break       
    return a    
print(phan_tich_n())